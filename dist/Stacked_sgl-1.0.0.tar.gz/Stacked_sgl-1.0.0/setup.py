# -*- coding: utf-8 -*-
"""
Created on Mon Dec  6 16:37:07 2021

@author: Administrator
"""

from distutils.core import setup
setup(name="Stacked_sgl", version="1.0.0", description="method of stacked sgl", 
      url= 'https://github.com/huanheaha/stacked-SGL.git',
      author="huanhe", py_modules=['Stacked_sgl.s_sgl'])